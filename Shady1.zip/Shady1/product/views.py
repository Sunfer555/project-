from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.

def ok(request):
    tags = ["ที่นี่","ที่นั้น","ที่อยู่","ที่ไหน",]
    return render(request,'ok.html',{'tags':tags})
